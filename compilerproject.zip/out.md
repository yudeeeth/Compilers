	decl KANNA_n
	push 5
	push 5
	add
	pop KANNA_n

	push KANNA_n
	push 1
	eq
	push 0
	jeq label2
	push KANNA_n
	print
	jmp label1
label2:
	push KANNA_n
	push 1
	add
	print
label1:
	push 0
	pop KANNA_n
	push 0
	pop KANNA_n
label3:
	push KANNA_n
	push 5
	lt
	push 0
	jeq label4
	push KANNA_n
	print
	print " "
	push KANNA_n
	push 1
	add
	pop KANNA_n
	jmp label3
label4:


interpreter starts from here:
110 1 2 3 4 