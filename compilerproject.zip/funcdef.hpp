#include <string>
#include <vector>
#include <unordered_map>
using namespace std;

class func_def{
    public:
    void* func_def_tree;
    vector<string> args_list;
};

